#!coding:utf-8


import gtk


class LingWallBg(gtk.Window):
    def __init__(self):
        gtk.Window.__init__(self, gtk.WINDOW_TOPLEVEL)
        # 初始化变量.
        self.init_values()
        # 初始化设置.
        self.init_set_ling_wall_bg()
    
    def init_values(self):
        screen = self.get_screen()
        self.screen_width, self.screen_height = screen.get_width(), screen.get_height()

    def init_set_ling_wall_bg(self):
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DESKTOP) 
        self.set_wall_bg_size(self.screen_width, self.screen_height)
        
    def set_wall_bg_size(self, width, height):
        self.set_size_request(width, height)
    
ling_wall_bg = LingWallBg()
ling_wall_bg.show_all()
gtk.main()
