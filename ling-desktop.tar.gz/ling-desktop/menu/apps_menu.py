

import gmenu
import gtk

class AppSystem(object):
    def __init__(self):
        self.categories = [] 
        self.apps_menu = gmenu.lookup_tree("applications.menu", gmenu.FLAGS_INCLUDE_EXCLUDED)
        self.apps_menu.add_monitor(self.apps_menu_add_monitor)
        self.update_app_system()

    def update_app_system(self):
        self.update_categories_index()
        self.update_apps()

    def update_apps(self):
        for cat in self.categories:
            print "id:", cat.get_menu_id()
            self.get_apps_by_category(cat)

    def update_categories_index(self):
        print "update_categories_index..."
        root_tree = self.apps_menu.get_root_directory()
    
        for item in root_tree.get_contents():
            print "item:", item.get_type()
            self.categories.append(item)

    def get_apps_by_category(self, category):
        app_list = []
        for item in category.get_contents():
            if item.get_type() == gmenu.TYPE_ENTRY:
                print "app:", "id:", item.get_type(), "name:", item.get_display_name()

    def apps_menu_add_monitor(self, gmenu_widget):
        print "fjdkslfjdsklfjdsklf...."
        update_categories_index()
    

AppSystem()
gtk.main()
