#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


#!coding:utf-8

import gmenu
from theme_icon import ThemeIcon 
import gtk
import os

OTHER_ICON_PATH = "/usr/share/icons/Faenza"

class AppSystem(object):
    def __init__(self):
        self.categories = [] 
        self.apps = {}
        self.index_changed = False
        #
        self.init_icons_path()
        #
        self.apps_menu = gmenu.lookup_tree("applications.menu", gmenu.FLAGS_INCLUDE_EXCLUDED)
        self.apps_menu.add_monitor(self.apps_menu_add_monitor)
        self.update_app_system()

    def init_icons_path(self):
        '''Linux deepin.'''
        self.icons_path = []
        # 读取配置文件的环境变量，进行图标路径的加载.
        if os.path.exists(OTHER_ICON_PATH): 
            for path in os.listdir(OTHER_ICON_PATH):
                self.icons_path.append(os.path.join(os.path.join(OTHER_ICON_PATH, path), "scalable"))


    def get_type_list(self):
        return self.categories

    def update_app_system(self):
        self.update_categories_index()
        self.update_apps()

    def update_categories_index(self):
        #print "update_categories_index..."
        root_tree = self.apps_menu.get_root_directory()
        # 
        if  self.categories == [] or self.index_changed:
            for item in root_tree.get_contents():
                if item.get_type() == gmenu.TYPE_DIRECTORY:
                    self.categories.append(item)

    def update_apps(self):
        if self.index_changed:
            self.apps.clear()
            self.apps = {}
            self.index_changed = False

        if self.apps == {}:
            for cat in self.categories:
                #print "类型:", cat.get_menu_id()
                # save apps dict.
                self.apps[cat.get_menu_id()] = self.get_apps_by_category(cat)

    def get_apps_by_category(self, category):
        app_list = []
        self.app_pixbuf = []
        for item in category.get_contents():
            if item.get_type() == gmenu.TYPE_ENTRY:
                if self.is_entry(item):
                    app = ThemeIcon(item, self.icons_path)
                    #app.launchd.connect("launched", self.app_launchd)
                    app_list.append(app)

        return app_list
        
    def app_launchd(self, app):
        app_uri = None
        if app.desktop_id != None:
            app_uri = "application://" + app.desktop_id
        self.push_app_launch(app_uri, app.name)
        # self.reload_relevancies ()

    def push_app_launch(self, uri, name):
        pass # zeitgeist.event.. subject...

    def is_entry(self, item):
        if (item.get_launch_in_terminal() == False 
            and item.get_is_nodisplay() == False):
            return True
        else:
            return False

    def apps_menu_add_monitor(self, gmenu_widget):
        self.index_changed = True
        self.update_app_system()
    

if __name__ == "__main__":
    def test_run_menu_app(widget, event, item):
        item.launch()

    win = gtk.Window(gtk.WINDOW_TOPLEVEL)
    scr_win = gtk.ScrolledWindow()
    main_vbox = gtk.VBox()
    scr_win.add_with_viewport(main_vbox)
    app_system = AppSystem()
    for cat in app_system.categories:
        main_vbox.pack_start(gtk.Button(cat.get_menu_id()))
        for item in app_system.apps[cat.get_menu_id()]:
            click_image = gtk.EventBox()
            click_image.connect("button-press-event", test_run_menu_app, item)
            image = gtk.image_new_from_pixbuf(item.icon)
            click_image.add(image)
            main_vbox.pack_start(click_image, False, False)
            
    win.add(scr_win)
    win.show_all()
    gtk.main()
