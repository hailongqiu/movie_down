#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import gtk
import gio
import os
import subprocess
from lingshot import Slingshot

class ThemeIcon(object):
    # 创建信号 icon_changed
    def __init__(self, entry, icons_path):
        self.slingshot = Slingshot()
        self.slingshot.icon_size = 50
        self.is_command = False
        for path in icons_path:
            self.slingshot.icon_theme.append_search_path(path)
        #
        self.name =  entry.get_display_name()
        self.description = entry.get_comment()
        self.exec_ = entry.get_exec()
        self.desktop_id = entry.get_desktop_file_id()
        self.icon_name = entry.get_icon()
        self.desktop_path = entry.get_desktop_file_path()
        self.icon = None # save pixbuf.
        #
        '''
        print "name:", self.name 
        print "description:", self.description 
        print "exec:", self.exec_ 
        print "desktop_id:", self.desktop_id 
        print "icon_name:", self.icon_name 
        print "desktop_path:", self.desktop_path
        '''
        #
        self.update_icon()
        self.slingshot.icon_theme.connect("changed", self.update_icon)

    def from_command(command):
        self.description = "Run this command..."
        self.exec_ = command
        self.desktop_id = command
        self.icon_name = "system-run"
        self.is_command = True
        self.update_icon()

    def update_icon(self):
        try:
            self.icon = self.slingshot.icon_theme.load_icon(
                                self.icon_name,
                                self.slingshot.icon_size,
                                gtk.ICON_LOOKUP_FORCE_SIZE)
        except:
            try:
                if self.icon_name.find(".") != -1:
                    path = self.icon_name[0:self.icon_name.find(".")]
                    #print "path:", path
                    self.icon = self.slingshot.icon_theme.load_icon(
                                    path, 
                                    self.slingshot.icon_size.
                                    gtk.ICON_LOOKUP_FORCE_SIZE)
                else:
                    raise IOError
            except:
                try:
                    self.icon = gtk.gdk.pixbuf_new_from_file_at_size(
                                    self.icon_name,
                                    self.slingshot.icon_size,
                                    self.slingshot.icon_size)
                except Exception , e:
                    try:
                        self.icon = self.slingshot.icon_theme.load_icon(
                                "applications",
                                self.slingshot.icon_size,
                                gtk.ICON_LOOKUP_FORCE_SIZE)
                    except:
                        self.icon = self.slingshot.icon_theme.load_icon(
                                "deepin-media-player",
                                self.slingshot.icon_size,
                                gtk.ICON_LOOKUP_FORCE_SIZE)
        #
        # self.emit("icon_changed")

    def launch(self):
        # run applicatoins.
        try:
            if self.is_command:
                subprocess.Popen(self.exec_)
            else:
                gio.AppInfo(self.exec_).launch()
        except Exception, e:
            print "Failed to lauch%s: %s", self.name, self.exec_ 






