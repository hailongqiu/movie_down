#!coding:utf-8

import gtk

class LingDock(gtk.Window):
    def __init__(self):
        gtk.Window.__init__(self, gtk.WINDOW_TOPLEVEL)
        # 初始化变量.
        self.init_values()
        # 初始化设置.
        self.init_set_ling_dock()
        
        
        icon_theme = gtk.IconTheme()
        print icon_theme.get_search_path()
        image = gtk.image_new_from_pixbuf(icon_theme.load_icon("deepin-media-player", 30, gtk.ICON_LOOKUP_FORCE_SIZE))
        self.add(image)
        
    def init_values(self):
        screen = self.get_screen()
        self.screen_width, self.screen_height = screen.get_width(), screen.get_height()
        
    def init_set_ling_dock(self):
        self.set_decorated(False)
        self.set_app_paintable(True)
        self.set_colormap(gtk.gdk.Screen().get_rgba_colormap())
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DOCK)
        self.set_dock_height(30)
        
        #gtk.gdk.x11_display_get_xdisplay(self.get_xdisplay())
        print "display:", self.get_screen().get_display()

    def set_dock_height(self, height):
        self.set_size_request(self.screen_width, height)

ling_dock = LingDock()
ling_dock.show_all()
gtk.main()

