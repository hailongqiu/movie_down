import glib
import gtk


PANEL_DEFAULT_MENU_ICON_SIZE = 24
PANEL_STOCK_FORCE_QUIT = "gnome-panel-force-quit"

PANEL_STOCK_EXECUTE = "panel-execute"
PANEL_STOCK_CLEAR   = "panel-clear"
PANEL_STOCK_DONT_DELETE = "panel-dont-delete"


class PanelStockIcon:
    def __init__(self):
        self.stock_id = ""
        self.icon     = ""

class PanelStockItem:
    def __init__(self):
        self.stock_id = ""
        self.stock_icon_id = ""
        self.label = ""

class Test(object):
    def __init__(self):
        self.stock_icons = [PanelStockIcon()]
        print self.stock_icons[0].stock_id
        
        
    def panel_init_stock_icons(self, factory):
        '''factory:gtk.IconFactory()'''
        source = gtk.IconSource()
        i = 0;
        for i in range(0, G_N_ELEMENTS(stock_icons)):
            set = gtk.IconSet()
            source.set_icon_name(self.stock_icons[i].icon)

            set.add_source(source)
            factory.add(self.stock_icons[i].stock_id, set)

    def panel_init_stock_items(self, factory):
        items = gtk.StockItem()
        '''
        for i in range(0, 10):
            items[i].stock_id = 
            items[i].label = 
            items[i].modifier = 
            items[i].keyval = 
            items[i].translation_domain = 
        '''

    def panel_init_stock_icons_and_items(self):
        factory = gtk.IconFactory()
        panel_menu_icon_size = gtk.icon_size_register("",
                                    0, 
                                    0)
        factory.add_default()
        self.panel_init_stock_icons(factory)
        self.panel_init_stock_items(factory)
if __name__ == "__main__":
    Test()
    gtk.main()
