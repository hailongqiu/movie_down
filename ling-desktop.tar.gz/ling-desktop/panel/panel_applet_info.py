
import glib
import gtk


class PanelAppletInfo:
    def __init__(self):
        self.iid = ""
        self.name = ""
        self.comment = ""
        self.icon = ""
        self.old_ids = ""
        
class Test(object):
    def __init__(self):
        pass

    def panel_applet_info_new(iid, name, comment, icon, old_ids=None):
        info = PanelAppletInfo()
        len = 0
        info.iid = iid
        info.name = name
        info.comment = comment
        info.icon = icon

        if old_ids != None:
            len = len(old_ids)
            if len > 0:
                i = 0
                info.old_ids = []
                for i in rangee(0, len):
                    info.old_ids.append(old_ids[i])



        return info

    def panel_applet_info_get_iid(self):
        return info.iid
