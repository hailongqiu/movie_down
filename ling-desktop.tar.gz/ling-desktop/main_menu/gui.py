#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import gtk
from apps_menu import AppSystem
from vtk.window import Window


class MainMenuGui(object):
    def __init__(self):
        self.app_system = AppSystem()
        self.app_system.connect("changed-apps", self.app_system_changed_apps)
        self.main_menu_main_vbox = gtk.VBox()
        self.scr_win = gtk.ScrolledWindow()
        self.search_text = gtk.TextView()
        self.search_text.set_size_request(120, 30)
        self.scr_win_ali = gtk.Alignment(0, 0, 1, 1)
        #
        main_vbox = gtk.VBox()

        for cat in self.app_system.categories:
            main_vbox.pack_start(gtk.Button(cat.get_menu_id()))
            for item in self.app_system.apps[cat.get_menu_id()]:
                click_image = gtk.EventBox()
                click_image.connect("button-press-event", self.test_run_menu_app, item)
                image = gtk.image_new_from_pixbuf(item.icon)
                image.set_tooltip_text(item.name)
                click_image.add(image)
                main_vbox.pack_start(click_image, False, False)
        #
        self.scr_win_ali.add(main_vbox)
        self.scr_win.add_with_viewport(self.scr_win_ali)
        self.main_menu_main_vbox.pack_start(self.scr_win)
        self.main_menu_main_vbox.pack_start(self.search_text, False, False)

    def test_run_menu_app(self, widget, event, item):
        item.launch()

    def app_system_changed_apps(self, apps):
        print "app_system_changed_apps..."
        self.scr_win_ali.remove(self.scr_win_ali.get_children()[0])
        main_vbox = gtk.VBox()
        for cat in self.app_system.categories:
            main_vbox.pack_start(gtk.Button(cat.get_menu_id()))
            for item in self.app_system.apps[cat.get_menu_id()]:
                click_image = gtk.EventBox()
                click_image.connect("button-press-event", self.test_run_menu_app, item)
                image = gtk.image_new_from_pixbuf(item.icon)
                image.set_tooltip_text(item.name)
                click_image.add(image)
                main_vbox.pack_start(click_image, False, False)
        #
        self.scr_win_ali.add(main_vbox)
        self.scr_win_ali.show_all()
        self.show_all()

if __name__ == "__main__":
    win = Window()
    main_menu = MainMenuGui()
    win.main_ali.add(main_menu.main_menu_main_vbox)
    win.set_size_request(200, 500)
    win.show_all()
    gtk.main()



