#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from dtk.ui.utils import propagate_expose
import cairo
import gtk

class TrayIcon(gtk.Window):
    def __init__(self,
                 y_padding=10, 
                 triangle_width=6,
                 triangle_y_padding=6
                 ):
        gtk.Window.__init__(self, gtk.WINDOW_POPUP)
        # init values.
        self.y_padding = y_padding
        self.triangle_width = triangle_width
        self.triangle_y_padding = triangle_y_padding
        # init setting.初始化设置.
        self.set_title("Linux Deepin Desktop Trayicon")
        self.set_can_focus(True)
        self.set_skip_pager_hint(True)
        self.set_skip_taskbar_hint(True)
        self.set_keep_above(True)                        
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
        # init event.初始化事件.
        self.add_events(gtk.gdk.ALL_EVENTS_MASK)
        self.connect("show", self.init_menu)
        self.connect("destroy", lambda w : gtk.main_quit()) 
        self.connect("button-press-event", self.menu_grab_window_button_press)
        self.connect("expose-event", self.window_expose_evnet)
        self.connect("size-allocate", self.draw_shape_mask)
        # init trayicon.初始化托盘.
        self.init_tray_icon()        
        # init root and screen.
        self.root = self.get_root_window()
        self.screen = self.root.get_screen()        
        self.hide_all()
        
    def init_menu(self, widget):
        # 绑定 motion press release....
        gtk.gdk.pointer_grab(
            self.window, 
            True,
            gtk.gdk.POINTER_MOTION_MASK 
            | gtk.gdk.BUTTON_PRESS_MASK 
            | gtk.gdk.BUTTON_RELEASE_MASK 
            | gtk.gdk.ENTER_NOTIFY_MASK 
            | gtk.gdk.LEAVE_NOTIFY_MASK,
            None,
            None, 
            gtk.gdk.CURRENT_TIME)
                    
    def menu_grab_window_button_press(self, widget, event):
        # 取消鼠标 grab.
        if not ((0 <= event.x <= widget.allocation.width)
            and (0 <= event.y <= widget.allocation.height)):
            gtk.gdk.pointer_ungrab(gtk.gdk.CURRENT_TIME)
            self.grab_remove()
            self.hide_all()
            
    def window_expose_evnet(self, widget, event):    
        cr = widget.window.cairo_create()
        rect = widget.allocation        
        #                
        #
        propagate_expose(widget, event)
        return True
    
    def draw_shape_mask(self, widget, rect):    
        # Init.
        x, y, w, h = rect.x, rect.y, rect.width, rect.height
        bitmap = gtk.gdk.Pixmap(None, w, h, 1)
        cr = bitmap.cairo_create()        
        # Clear the bitmap
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.paint()
        #
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.set_operator(cairo.OPERATOR_OVER)
        cr.rectangle(x, y, w, h - self.triangle_y_padding)
        cr.fill()
        # 
        self.draw_triangle(cr, x, y, w, h)
        #
        # Shape with given mask.
        widget.shape_combine_mask(bitmap, 0, 0)
        
    def draw_triangle(self, cr, x, y, w, h):        
        cr.move_to(x + w/2 - self.triangle_width, 
                   y + h - self.triangle_y_padding)
        cr.line_to(x + w/2 , 
                   y+h)
        cr.line_to(x + w/2 + self.triangle_width, 
                   y + h - self.triangle_y_padding)
        cr.fill()
        
    def init_tray_icon(self):
        self.tray_icon = gtk.StatusIcon()
        # set icon.设置图标.
        self.tray_icon.set_from_file("icon.png")        
        self.tray_icon.set_visible(True)
        # init events.
        self.tray_icon.connect("activate", self.tray_icon_activate)
        self.tray_icon.connect('popup-menu', self.tray_icon_popup_menu)        
        print self.tray_icon.get_x11_window_id()
         
    def tray_icon_activate(self, status_icon):
        self.show_menu()
        
    def tray_icon_popup_menu(self, status_icon, button, activate_time):
        self.show_menu()
        
    def show_menu(self):    
        metry = self.tray_icon.get_geometry()
        tray_icon_rect = metry[1]        
        # get screen height. 获取屏幕的高.
        screen_h = self.screen.get_height()
        #
        if (screen_h / 2) <= tray_icon_rect[1] <= screen_h: # 下部托盘显示.
            y_padding = 10 + self.y_padding
            self.move(tray_icon_rect[0] + tray_icon_rect[2]/2 - self.get_size_request()[0]/2, 
                      tray_icon_rect[1] - tray_icon_rect[3]  + y_padding - self.get_size_request()[1])
        else: # 上部托盘显示.
            y_padding = 15 - self.y_padding
            self.move(tray_icon_rect[0] + tray_icon_rect[2]/2 - self.get_size_request()[0]/2, 
                  tray_icon_rect[1] + tray_icon_rect[3] + y_padding)
        #   
        self.show_all()
        
if __name__ == "__main__":        
    tray_icon = TrayIcon(triangle_width=6, 
                         triangle_y_padding=6)        
    tray_icon.set_opacity(0.95)
    tray_icon.set_size_request(300, 200)
    vbox = gtk.VBox()
    vbox.pack_start(gtk.Button("fdsjkl"), False, False)
    tray_icon.add(vbox)
    gtk.main()
