#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from constant import DEBUG
import threading
import os



def get_home_path():
    return os.path.expanduser("~")

def allocation(widget): # 返回 cr, rect.
    cr = widget.window.cairo_create()
    rect = widget.get_allocation()
    return cr, rect
                    
def get_paly_file_name(path): # 获取播放文件名.
    return os.path.splitext(os.path.split(path)[1])[0]

def get_paly_file_type(path): # 获取播放后缀名.
    return os.path.splitext(os.path.split(path)[1])[1][1:]


def length_to_time(length): # 长度转时间.
    time_sec = int(float(length))
    time_hour = 0
    time_min = 0
    
    if time_sec >= 3600:
        time_hour = int(time_sec / 3600)
        time_sec -= int(time_hour * 3600)
        
    if time_sec >= 60:
        time_min = int(time_sec / 60)
        time_sec -= int(time_min * 60)         
        
    return str("%s:%s:%s"%(str(time_add_zero(time_hour)), 
                           str(time_add_zero(time_min)), 
                           str(time_add_zero(time_sec))))

def time_add_zero(time_to):    
    if 0 <= time_to <= 9:
        time_to = "0" + str(time_to)
    return str(time_to)

def get_file_size(path): # 获取文件大小.
    if os.path.exists(path):
        file_size = os.path.getsize(path)            
        return size_to_format(file_size)
    else:
        return 0
    
diskunit = ['Byte', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']

def size_to_format(size, unit='Byte'): # size 转换成k/b/g/t/p/e->B显示.
    if size < 1024:
        return '%.2f %s' % (size, unit)
    else:
        return size_to_format(size/1024.0, diskunit[diskunit.index(unit) + 1])                
    

def debug_msg(function_name, msg):
    if DEBUG:
        print "%s:%s" % (function_name, msg)

