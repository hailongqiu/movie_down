#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from constant import DEBUG
import threading
import gobject        
import gtk
import os



def get_home_path():
    return os.path.expanduser("~")

def allocation(widget): # 返回 cr, rect.
    cr = widget.window.cairo_create()
    rect = widget.get_allocation()
    return cr, rect
                    
def get_paly_file_name(path): # 获取播放文件名.
    return os.path.splitext(os.path.split(path)[1])[0]

def get_paly_file_type(path): # 获取播放后缀名.
    return os.path.splitext(os.path.split(path)[1])[1][1:]


def length_to_time(length): # 长度转时间.
    time_sec = int(float(length))
    time_hour = 0
    time_min = 0
    
    if time_sec >= 3600:
        time_hour = int(time_sec / 3600)
        time_sec -= int(time_hour * 3600)
        
    if time_sec >= 60:
        time_min = int(time_sec / 60)
        time_sec -= int(time_min * 60)         
        
    return str("%s:%s:%s"%(str(time_add_zero(time_hour)), 
                           str(time_add_zero(time_min)), 
                           str(time_add_zero(time_sec))))

def time_add_zero(time_to):    
    if 0 <= time_to <= 9:
        time_to = "0" + str(time_to)
    return str(time_to)

def get_file_size(path): # 获取文件大小.
    if os.path.exists(path):
        file_size = os.path.getsize(path)            
        return size_to_format(file_size)
    else:
        return 0
    
diskunit = ['Byte', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']

def size_to_format(size, unit='Byte'): # size 转换成k/b/g/t/p/e->B显示.
    if size < 1024:
        return '%.2f %s' % (size, unit)
    else:
        return size_to_format(size/1024.0, diskunit[diskunit.index(unit) + 1])                
    

def debug_msg(function_name, msg):
    if DEBUG:
        print "%s:%s" % (function_name, msg)

        
##########################################
## 线程扫描目录.  
## scan_dir = ScanDir('/home')
## scan_dir.connect("scan-file-event",self.scan..  ..
## def scan_file_event(scan_dir, file_name):...        
class ScanDir(gobject.GObject):                
    __gsignals__ = {
        "scan-file-event" : (gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE,
                             (gobject.TYPE_STRING,)),
        "scan-end-event" : (gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE,
                             ()),        
        }            
    def __init__(self, path):
        gobject.GObject.__init__(self)
        self.event = threading.Event()
        self.path = path
        self.__run()
        
    def pause(self): # 暂停线程
        self.event.clear()
        
    def start(self): # 开启线程
        self.event.set()
        
    def __wait(self):  
        self.event.wait()
        
    def enter(self):    
        gtk.gdk.threads_enter()
        
    def leave(self):    
        gtk.gdk.threads_leave()        
        
    def __scan(self, path):
        self.__wait()
        try:
            if os.path.isdir(path):
                for file_ in os.listdir(path):
                    file_path = os.path.join(path, file_)
                    for sub_file in self.__scan(file_path):
                        yield sub_file
            else:    
                yield path
        except:
            print "read file error!!"
                    
    def __run(self):
        scan_th = threading.Thread(target=self.__run_func)
        scan_th.setDaemon(True) 
        scan_th.start()
        
    def __run_func(self):    
        for file_ in self.__scan(self.path):
            self.emit("scan-file-event", file_)
        self.emit("scan-end-event")    
        
if __name__ == "__main__":            
    gtk.gdk.threads_init()    
    def scan_file_event(scan_dir, file_name):
        gtk.gdk.threads_enter()
        label.set_label(file_name)
        gtk.gdk.threads_leave()
        
    def scan_end_event(scan_dir):    
        gtk.gdk.threads_enter()
        label.set_label("%s扫描完毕"%(scan_dir.path))
        gtk.gdk.threads_leave()        
        
    def start_btn_clicked(widget):    
        scan_dir.start()
        
    def pause_btn_clicked(widget):    
        scan_dir.pause()
        
    scan_dir = ScanDir("/")
    scan_dir.connect("scan-file-event", scan_file_event)                
    scan_dir.connect("scan-end-event", scan_end_event)
    win = gtk.Window(gtk.WINDOW_TOPLEVEL)
    win.set_title("线程测试!!")
    vbox = gtk.VBox()
    hbox = gtk.HBox()
    start_btn=gtk.Button("开始")
    pause_btn=gtk.Button("暂停")    
    hbox.pack_start(start_btn, False, False)
    hbox.pack_start(pause_btn, False, False)
    label = gtk.Label("...")    
    vbox.pack_start(hbox, False, False)
    vbox.pack_start(label, False, False)
    win.add(vbox)    
    win.connect("destroy", lambda w : gtk.main_quit())    
    start_btn.connect("clicked", start_btn_clicked)
    pause_btn.connect("clicked", pause_btn_clicked)
    win.show_all()
    
    gtk.gdk.threads_enter()
    gtk.main()
    gtk.gdk.threads_leave()
