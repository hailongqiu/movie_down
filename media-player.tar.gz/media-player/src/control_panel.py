#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import gtk

class ControlPanel(gtk.HBox):
    def __init__(self):
        gtk.HBox.__init__(self)
        self.stop_button = gtk.Button("停止")
        self.bseek_button = gtk.Button("倒退")
        self.start_button = gtk.Button("暂停")
        self.fseek_button = gtk.Button("快进")
        self.open_button = gtk.Button("打开")
        
        self.pack_start(self.stop_button, False, False)
        self.pack_start(self.bseek_button, False, False)
        self.pack_start(self.start_button, False, False)
        self.pack_start(self.fseek_button, False, False)
        self.pack_start(self.open_button, False, False)
