#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from skin import app_theme
from dtk.ui.menu import Menu
from dtk.ui.menu import MenuItem
from dtk.ui.constant import DEFAULT_FONT_SIZE, MENU_ITEM_RADIUS
from dtk.ui.constant import ALIGN_START, ALIGN_MIDDLE, WIDGET_POS_RIGHT_CENTER, WIDGET_POS_TOP_LEFT
from dtk.ui.utils import get_widget_root_coordinate
from dtk.ui.constant import WIDGET_POS_BOTTOM_LEFT
from locales import _

'''
'''

class TitleMenu(object):
    '''标题栏菜单'''
    def __init__(self):
        '''file'''
        self.file_play_memory = NewMenu([(None, _("立即清除播放痕迹"), None),
                                    (None),
                                    (None, _("退出时清除播放痕迹"), None),
                                    (None, _("退出时保留播放痕迹"), None),
                                    ])        
        self.file = NewMenu([(None, _("Open File"), None),
                             (None, _("Open Directory"), None),
                             (None, _("Open Url"), None),
                             (None, _("Play Disc"), None),
                             (None),
                             (None, _("播放记忆"), self.file_play_memory)
                             ])
        '''play'''
        self.play = NewMenu([(None, _("Full Screen"), None),
                             (None, _("Normal Mode"), None),
                             (None, _("Compact Mode"), None),
                             (None, _("Previous"), None),
                             (None, _("Next"), None),
                             (None),
                             (None, _("Jump Forward"), None),
                             (None, _("Jump Backward"), None),
                             (None, _("Order"), None),                                     
                             ])
        '''video'''
        self.video = NewMenu([(None, _("Original"), None),
                              (None, "4:3", None),
                              (None, "16:9", None),
                              (None, "16:10", None),
                              (None, "1.85:1", None),
                              (None, "2.35:1", None),
                              (None),
                              (None,  _("50%"),  None),
                              (None,  _("100%"), None),
                              (None,  _("150%"), None),
                              (None,  _("200%"), None),                              
                              ])
        '''Audio'''
        self.audio_channel = Menu([(None, _("Stereo"), None),
                                   (None,   _("Left"),   None),
                                   (None,  _("Right"),   None)
                                   ])
        self.audio = Menu([(None, _("Channels"), self.audio_channel),
                           (None),
                           (None, _("Increase Volume"),  None),
                           (None, _("Decrease Volume"),  None),
                           (None, _("Mute/Unmute"), None),
                           ])
        '''root { audio, video, play, file... ...} .主菜单'''
        self.root = NewMenu([(None, _("File"), self.file),
                             (None, _("Play"), self.play),
                             (None, _("Video"), self.video),
                             (None, _("Audio"), self.audio),
                             (None),
                             (None, _("Take Screenshots"), None),
                             (None, _("Format conversion"), None),
                             (None),
                             (None, _("View New Features"), None),
                             (None, _("Preferences"), None),
                             (None),
                             (None, _("Quit"), None)                             
                             ], True)
        #
        
    def show(self, button):
        self.root.show_menu(button)
                
#################################################################################
class NewMenu(Menu):
    def __init__(self, items=[], check=False):
        if check:
            Menu.__init__(self, items, check)
        else:    
            Menu.__init__(self, items)
        
    def show_menu(self, button):            
        self.show(
            get_widget_root_coordinate(button, WIDGET_POS_BOTTOM_LEFT),
            (button.get_allocation().width, 0))  
        
    def set_pixbuf(self, index, pixbuf):
        item_list = list(self.menu_items[index].item)
        item_list[0] = pixbuf
        self.menu_items[index].item = tuple(item_list)
    
    def set_event(self, index, event):    
        item_list = list(self.menu_items[index].item)
        item_list[2] = event
        self.menu_items[index].item = tuple(item_list)                
        
#################################################################################        
